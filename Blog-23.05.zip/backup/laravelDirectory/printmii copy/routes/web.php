<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomAuth;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ImagesController;
use Illuminate\Support\Facades\DB;
use App\Models\Product;
use App\Models\Images;
use App\Models\Categories;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/admin', function () {
    return view('homepage');
});
Route::get('/adminCategory', function () {
    return view('category');
});
Route::get('/productEdit/{id}', function ($id) {
    return view('edit',[
        "products" => DB::select("SELECT * FROM products WHERE id = $id"),
        "images" =>DB::select("SELECT * FROM images WHERE product_id = $id"),
        "product_id"=>$id,
        "categories"=>Categories::all(),
    ]);
});

Auth::routes();

Route::get('/', [CustomAuth::class, 'home'])->name('home');
Route::get('register', [CustomAuth::class, 'register'])->name('register');
Route::post('postlogin', [CustomAuth::class, 'login'])->name('postlogin');
Route::post('signup', [CustomAuth::class, 'signup'])->name('signup');
Route::post('addCategory', [AdminController::class, 'addCategory'])->name('addCategory');
Route::any('addProduct/{img}', [AdminController::class, 'create']);
Route::any('editProduct/{id}/{img}', [AdminController::class, 'update']);
Route::post('/upload', [ImagesController::class, 'upload']);
Route::any('deleteImage/{id}', [ImagesController::class, 'destroy']);


