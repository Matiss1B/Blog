function upload(){
        let myFile = $("#gallery").prop("files");
        for (var i = 0; i <= myFile.length; i++) {
            var src = URL.createObjectURL(myFile[i]);
            let name = myFile[i]['name'];
            $(".imagesList").append(
                "<div>" + "<div id = 'del-" +
                i +
                "'  onclick='del(" +
                i +
                ")'>X</div> <img style='height:150px; width: 200px' src='" +
                src +
                "' id = 'img-" +
                i +
                "' > "
            );
            console.log($("#gallery").prop("files"));
        }
}
function mainImgChange(){
    let myFile = $("#main_img").prop("files");
    for (var i = 0; i <= myFile.length; i++) {
        var src = URL.createObjectURL(myFile[i]);
        let name = myFile[i]['name'];
        $("#main-img").html("");
        $("#main-img").append(
            "<img style='height:200px; width: 200px' src='" +
            src +
            "' id = 'img-" +
            i +
            "' > "
        );
        console.log($("#gallery").prop("files"));
    }
}
function addDetail(index){
    var i = index+1;
    var detail = "<div id = 'detail-box-"+i+"'>"+"<input type='text' placeholder='Detail title' name='detail_title-"+ i +"' id='detail_title-"+ i +"'>"+
    "<input type='text' placeholder='Detail' name='detail-"+ i +"' id='detail-"+ i +"'>"+
        "<p id ='detBtn-"+ i +" ' onClick='addDetail("+ i +")'>Add one more detail</p>"+"</div>";
    $("#details").append(detail);
    $("#detBtn-"+index).remove();
}
var arr =[];
function del(index) {
    let File = $("#gallery").prop("files");
    $("#img-" + index).remove();
    $("#del-" + index).remove();
    $("#main-" + index).remove();
    arr.push(File[index]["name"]);
    console.log(arr);
}
function addProduct(){
    if(arr.length>0) {
        var images = arr;
    }else{
        images = "null";
    }
    var count = document.getElementById("details").children.length
    document.getElementById("productForm").action =
        "addProduct/"+images+"/"+count;
}
function editProduct(id){
    if(arr.length>0) {
        var images = arr;
    }else{
        images = "null";
    }
    document.getElementById("editForm").action =
        "http://localhost/laravelDirectory/printmii/public/editProduct/"+ id +"/"+images;
}
function delImg(id) {
    var url = 'http://localhost/laravelDirectory/printmii/public/deleteImage/'+id;
    $.ajax({
        headers: {
            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
        },
        url: url,
        type: "POST",
        success: function (results) {
            $("#imageConatiner-"+id).remove();
        }
    });
}

