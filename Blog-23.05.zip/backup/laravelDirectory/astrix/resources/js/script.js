function register() {
    $(".hide-box-login").removeClass("none");
    $(".hide-box-register").addClass("none");
    $(".hide-box").css("animation-name", "hidelogin");
    $(".hide-box").css("animation-duration", "0.5s");
    $(".hide-box").css("left", "50%");
    $(".hide-box").css("border-radius", "0rem 1.5rem 1.5em 0rem");
    $(".hide-box-content-login").removeClass("none");
    $(".hide-box-content-register").addClass("none");
}
function login() {
    $(".hide-box-register").removeClass("none");
    $(".hide-box-login").addClass("none");
    $(".hide-box").css("animation-name", "hideregister");
    $(".hide-box").css("animation-duration", "0.5s");
    $(".hide-box").css("left", "0%");
    $(".hide-box").css("border-radius", "1.5rem 0rem 0em 1.5rem");
    $(".hide-box-content-register").removeClass("none");
    $(".hide-box-content-login").addClass("none");
}
