

let arr = [];
function drag() {
  let myFile = $("#fileinput").prop("files");
  for (var i = 0; i <= myFile.length; i++) {
    var src = URL.createObjectURL(myFile[i]);
    let name = myFile[i]['name'];
    $("body").append(
      "<div>"+"<div id = 'del-" +
        i +
        "'  onclick='del(" +
        i +
        ")'>X</div> <img style='height:300px; width: 400px' src='" +
        src +
        "' id = 'img-" +
        i +
        "' > "+"<div id = 'main-"+i+"' style = 'display:flex;'><p>Iestatīt kā titulattēlu</p> <input onclick='setMain("+i+")' id = '" + i + "' value='" + name + "' type='radio' name='radio'>"+"</div></div>"
    );
    console.log($("#fileinput").prop("files"));
  }
}
function del(index) {
  let File = $("#fileinput").prop("files");
  $("#img-" + index).remove();
  $("#del-" + index).remove();
  $("#main-" + index).remove();
  arr.push(File[index]["name"]);
  console.log(arr);
}
function setMain(index){
  let File = $("#fileinput").prop("files");
  localStorage.setItem("main", File[index]['name']);
  console.log(localStorage.getItem("main"));
}
function upload() {
  console.log($("#fileinput").prop("files"));
  if(arr.length<1){
    var deletedImages = 'all';
  }else{
    var deletedImages = arr;
  }
  console.log(deletedImages);
  var main = localStorage.getItem("main");
  document.getElementById("myForm").action =
    "http://localhost/mvc1/data/img/"+deletedImages+"/"+main;
}
