<?php
class Img {
    private $db;
    public function __construct(){
        $this->db = new Database;
    }
    private function compress_image($source_url, $destination_url, $size, $quality){
        $info = getimagesize($source_url);
        if ($info['mime'] == 'image/jpeg'){
            $image =  imagecreatefromjpeg($source_url);
        }elseif ($info['mime'] == 'image/png'){
            $image = imagecreatefrompng($source_url);
        }elseif ($info['mime'] == 'image/jpg'){
            $image =  imagecreatefromjpeg($source_url);
        }
        // if($size[0]>1024) {
        $image = imagescale($image, 1024);
        //}
        imagejpeg($image, $destination_url, $quality);
    }
    public function upload($imgData)
    {
        $check = true;
        $imgname =$imgData["tmp_name"];
        $source_photo = $imgname;
        $dest_photo = APPROOT."/assets/images/".basename($imgData['name']);
        $imageFileType = strtolower(pathinfo($dest_photo,PATHINFO_EXTENSION));
        if(empty($imgData["tmp_name"])){
            return "Lūdzu izvēlietes attēlu!";
            $check  = false;
        }
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
            return "Atvainojiet, iespējams augšupielādēt attēlu tikai ar šadiem formātiem(JPG, JPEG, PNG)";
            $check  = false;
        }
        if (file_exists($dest_photo)) {
            return "Atvainojiet, attēls jau eksistē!";
            $check = false ;
        }
        if($check){
            echo $dest_photo;
            //$this->compress_image($source_photo, $dest_photo, $imgData['size'], 75);
           /* $this->db->query('INSERT INTO images (img, is_main) VALUES(:img, :is_main)');
            $this->db->bind(':img', "assets/images/".basename($imgData['name']));
            $this->db->bind(':is_main', $imgData['is_main']);
            if($this->db->execute()){
                return 1;
            } else {
                return 0;
            }*/
        }
    }

}