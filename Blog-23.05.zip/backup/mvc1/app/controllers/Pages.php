<?php
  class Pages extends Controller {
    public function __construct(){
    }
    
    public function index(){
      $data = [
        'title' => 'Attēla augšupielāde',
      ];

      $this->view('admin/index', $data);
    }

  }