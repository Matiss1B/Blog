<?php
//session_start();
class Data extends Controller {

    public function __construct(){
        $this->imgModel = $this->model('Img');
    }
    public function getUrl($i){
        $url = rtrim ($_GET ['url'], '/');
        $url = filter_var ($url, FILTER_SANITIZE_URL);
        $url = explode ('/', $url);
        return $url[$i];
    }

    public function img(){
        if (!is_dir(APPROOT."/assets/images/")) {
            mkdir(APPROOT."/assets/images/");
        }
        $images = $this->getUrl(2);
        $main = $this->getUrl(3);
        $images = explode("," , $images);
        foreach($_FILES["img"]["tmp_name"] as $key=>$tmp_name) {
            if($images !== 'all'){
                if(!in_array($_FILES["img"]["name"][$key], $images)) {
                    if($_FILES["img"]["name"][$key] == $this->getUrl(3)){
                        $main = 1;
                    }else{
                        $main = 0;
                    }
                    $imgData = [
                        'name' => $_FILES["img"]["name"][$key],
                        'tmp_name' => $_FILES["img"]["tmp_name"][$key],
                        'size' => $_FILES["img"]["size"][$key],
                        'is_main'=>$main,
                    ];
                    if ($this->imgModel->upload($imgData) == 1) {
                        $data = [
                            'title' => "Attēla augšupielāde",
                            'message' => "Attēls augšupielādēts!",

                        ];
                        //$this->view('admin/index', $data);

                    } else {
                        $message = $this->imgModel->upload($imgData);
                        $data = [
                            'title' => "Attēla augšupielāde",
                            'message' => $message,

                        ];
                        //$this->view('admin/index', $data);
                    }
                }
            }else{
                if($_FILES["img"]["name"][$key] == $this->getUrl(3)){
                    $main = 1;
                }else{
                    $main = 0;
                }
                $imgData = [
                    'name' => $_FILES["img"]["name"][$key],
                    'tmp_name' => $_FILES["img"]["tmp_name"][$key],
                    'size' => $_FILES["img"]["size"][$key],
                    'is_main'=>$main,
                ];
                if ($this->imgModel->upload($imgData) == 1) {
                    $data = [
                        'title' => "Attēla augšupielāde",
                        'message' => "Attēls augšupielādēts!",

                    ];
                    //$this->view('admin/index', $data);
                    $images = [];
                } else {
                    $message = $this->imgModel->upload($imgData);
                    $data = [
                        'title' => "Attēla augšupielāde",
                        'message' => $message,

                    ];
                    //$this->view('admin/index', $data);
                }
            }
        }


    }

}