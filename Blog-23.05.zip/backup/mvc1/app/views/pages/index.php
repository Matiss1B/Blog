<?php require APPROOT . '/views/inc/header.php'; ?>
  <h1><?php echo $data['title']; ?></h1>
  <p>This is the TraversyMVC PHP framework. Please refer to the docs on how to use it</p>
<?php require APPROOT . '/views/inc/footer.php'; ?>
