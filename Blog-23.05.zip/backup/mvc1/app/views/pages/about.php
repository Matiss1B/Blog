<?php require APPROOT . '/views/inc/header.php'; ?>
    <form action = "<?php echo URLROOT; ?>/pages/about" method = "post">
        <button type="submit">ss</button>
    </form>
<?php require APPROOT . '/views/inc/footer.php'; ?>