<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <title>Document</title>
</head>
    <body>
        <form id = "myForm" method = "post" enctype="multipart/form-data">
            <h1><?php echo $data['title']; ?></h1>
            <span><?php
                if(!empty($data['message'])) {
                    echo $data['message'];
                }

                ?></span>
            <input type="file" onchange="drag()" accept="image/*" name = "img[]" id = "fileinput" multiple>
            <button type="submit" onclick = "upload()" >Ievietot</button>
        </form>
        <div class = "images" style="height: 300px; width: 400px;"></div>
    </body>
</html>
<script src = "http://localhost/mvc1/public/js/main.js"></script>

