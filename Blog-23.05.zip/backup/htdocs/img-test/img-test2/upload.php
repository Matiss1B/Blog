<?php
$images = $_GET['images'];
$images = explode("," , $images);
 // print_r($_POST['deletedImages']);

 
//  print_r($_FILES);
 foreach($_FILES["img"]["tmp_name"] as $key=>$tmp_name) {
     if(!in_array($_FILES["img"]["name"][$key], $images)){
        echo $_FILES["img"]["name"][$key]."  ";
     }
 }
// foreach($images as $img){
//     echo $img;

// }
