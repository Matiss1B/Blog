<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <title>Document</title>
</head>
    <body>
        <form id = "myForm" method = "post" enctype="multipart/form-data">
            <input type="file" onchange="drag()" accept="image/*" name = "img[]" id = "img" multiple>
            <button type="submit" onclick = "upload()" >Ievietot</button>
        </form>
        <div class = "images"></div>
    </body>
</html>
<script src = "script.js"></script>

