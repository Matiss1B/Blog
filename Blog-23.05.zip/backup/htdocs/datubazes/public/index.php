<?php
require_once '../app/bootrstrap.php';
 $init = new Core;