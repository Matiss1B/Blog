function box(id) {
  if (localStorage.getItem("box-" + id + "") !== "true") {
    var title = $("#box-" + id + "")
      .children("#infoAll")
      .children("#title")
      .text();
    var img = $("#box-" + id + "")
      .children("#infoAll")
      .children(".imgDiv")
      .children("#img")
      .prop("src");
    var desc = $("#box-" + id + "")
      .children("#infoAll")
      .children("#desc")
      .text();
    var author = $("#box-" + id + "")
      .children("#infoAll")
      .children("#info")
      .children("#author")
      .text();
    var date = $("#box-" + id + "")
      .children("#infoAll")
      .children("#info")
      .children("#date")
      .text();
    $.ajax({
      type: "POST",
      data: { title: title, img: img, desc: desc, author: author, date: date },
      url: "assets/ajaxFiles/insert.php",
      success: function (data) {
        $("#box-" + id + "").addClass("outline");
        $("#box-" + id + "")
          .children(".saved")
          .removeClass("none");
        localStorage.setItem("box-" + id + "", "true");
      },
    });
  } else {
    var desc = $("#box-" + id + "")
      .children("#infoAll")
      .children("#desc")
      .text();
    $.ajax({
      type: "POST",
      data: { desc: desc },
      url: "assets/ajaxFiles/delete.php",
      success: function (data) {
        $("#box-" + id + "").removeClass("outline");
        $("#box-" + id + "")
          .children(".saved")
          .addClass("none");
        localStorage.setItem("box-" + id + "", "false");
      },
    });
  }
}
window.onload = function () {
  //localStorage.clear();
  var lenght = $(".page").children().length;
  for (let i = 1; i <= lenght; i++) {
    var isButtonDisabled = localStorage.getItem("box-" + i + "") === "true";
    if (isButtonDisabled) {
      $("#box-" + i + "").addClass("outline");
      $("#box-" + i + "")
        .children(".saved")
        .removeClass("none");
    }
  }
};
// window.onload = function () {
//   localStorage.clear();
//   var lenght = $(".page").children().length;
//   for (let i = 1; i <= lenght; i++) {
//     var title = $("#box-" + i + "")
//       .children("#infoAll")
//       .children("#title")
//       .text();
//     var img = $("#box-" + i + "")
//       .children("#infoAll")
//       .children("#img")
//       .prop("src");
//     var desc = $("#box-" + i + "")
//       .children("#infoAll")
//       .children("#desc")
//       .text();
//     var author = $("#box-" + i + "")
//       .children("#info")
//       .children("#author")
//       .text();
//     var date = $("#box-" + i + "")
//       .children("#info")
//       .children("#date")
//       .text();
//     alert(title);
//     $.ajax({
//       type: "POST",
//       data: { title: title, img: img, desc: desc, author: author, date: date },
//       url: "assets/ajaxFiles/check.php",
//       success: function (data) {
//         alert(title);
//         // if (data == "true") {
//         //   var title = $("#box-" + i + "")
//         //     .children("#infoAll")
//         //     .children("#title")
//         //     .text();
//         //   alert(title);
//         //   $("#box-" + i + "").addClass("outline");
//         //   $("#box-" + i + "")
//         //     .children(".saved")
//         //     .removeClass("none");
//         // }
//       },
//     });
//     //alert("heu");
//     //alert(localStorage.getItem("box-" + i + ""));
//   }
//   for (let i = 1; i <= lenght; i++) {
//     // var isButtonDisabled = localStorage.getItem("box-" + i + "") === "true";
//     // if (isButtonDisabled) {
//     //   $("#box-" + i + "").addClass("outline");
//     //   $("#box-" + i + "")
//     //     .children(".saved")
//     //     .removeClass("none");
//     // }
//     //alert(localStorage.getItem("box-" + i + ""));
//   }
// };
