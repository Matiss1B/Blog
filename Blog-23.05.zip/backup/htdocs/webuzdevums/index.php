<?php
include "db.php";
$data = file_get_contents("http://into.id.lv/uzd/api.php?key=webuzdevums", true);
$data = json_decode($data);
$array1=[];
foreach($data as $unit){
    $unit = explode(";",$unit->name);
    $blog = [];
    $i=0;
    foreach($unit as $single){
        $single = explode("::",$single);
        if(!empty($single[1])){
            $blog[$i] = $single[1];
            $i++;
        }
    } 
    array_push($array1, $blog);   
}
$i=0;
//echo "<pre>";
 //print_r($array1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.co/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <title>Balins lohs</title>
</head>
<body class = "w-max h-max">
    <div class="page gap2">
    <?php foreach($array1 as $array){
        $i++?>
    <div class="box bgs2 flex col space-between" id ="box-<?php echo $i?>" >
        <div class="saved none">Saglabats</div>
        <div class="pad10px flex col justifyCenter alignCenter space-evenly gap1" id ="infoAll">
            <img id ="img" src="<?php echo $array[2] ?>" alt="kkkk">
            <h1 id = "title"><?php echo $array[0];?></h1>
            <p id ="desc"><?php echo $array[1];?></p>
            <div class="flex space-between w-max" id ="info">
                <p id = "author"><?php echo $array[3];?></p>
                <p id = "date"><?php echo $array[4];?></p>
            </div>
            <button class = "btn1" onclick="box(<?php echo $i?>)">Saglabat</button>
            <button class = "none" onclick="box(<?php echo $i?>)">Dzēst</button>
        </div>
    </div>
    <?php }?>
    </div>
</body>
<script src = "assets/script.js"></script>
</html>
