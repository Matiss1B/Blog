<?php
$host = 'localhost';
$dbname = 'webuzdeums';
$user = 'root';
$pass = 'Trubins1';
$conn = new mysqli($host, $user, $pass,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}