function add() {
  var text = $("#input").val();
  if (localStorage.getItem("id") == undefined) {
    localStorage.setItem("id", 1);
  } else {
    var nmb = localStorage.getItem("id");
    localStorage.setItem("id", Number(nmb) + 1);
  }
  $(".list").append(
    "<p class = 'flex' id = '" +
      localStorage.getItem("id") +
      "'>" +
      text +
      "<p onclick = 'del()'>-</p>" +
      "</p>"
  );
  localStorage.setItem(
    "job-" + localStorage.getItem("id") + "",
    "<p class = 'flex' id = '" +
      localStorage.getItem("id") +
      "'>" +
      text +
      "<p onclick = 'del(" +
      localStorage.getItem("id") +
      ")'>-</p>" +
      "</p>"
  );
}
function del(id) {
  localStorage.removeItem("job-" + id + "");
  $("#" + id + "").remove();
}
function clearAll() {
  localStorage.clear();
  window.location.href = "http://localhost:8888/javascriptToDo/";
}
window.onload = function () {
  var lenght = localStorage.getItem("id");
  for (let i = 1; i <= lenght; i++) {
    $(".list").append(localStorage.getItem("job-" + i + ""));
  }
};
