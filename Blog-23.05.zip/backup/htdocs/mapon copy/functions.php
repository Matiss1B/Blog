
<?php
$a =[];
$timezone_identifiers = DateTimeZone::listIdentifiers( DateTimeZone::PER_COUNTRY, "US" );
foreach( $timezone_identifiers as $identifier ) {
    array_push($a,$identifier);
}

$time = '20:12:32';
$date = '2004-04-02';
 $date = new DateTime("$date $time ", new DateTimeZone($a[0]));
 $date->setTimezone(new DateTimeZone("Europe/Riga"));
 $c2 =  $date->format('Y-m-d H:i:s') . "<br>";
 $c3 =  $date->format('Y-m-d H:i:s') . "<br>";
 $c3= date("d.m.Y");  
//  echo strtotime($c1)." ";
  //echo $c3." ";
//  $workingHours = (strtotime($c1) - strtotime($c2));
//  echo strtotime($c1);
  $PT = 1668536675;

// //  $Riga = 1668536785;
// //  echo $Riga- $PT;

function timeChange($time, $date ,$c_iso,$timeZoneTo){
    $a=[];
    $timezone_identifiers = DateTimeZone::listIdentifiers( DateTimeZone::PER_COUNTRY, $c_iso);
    foreach( $timezone_identifiers as $identifier ) {
        array_push($a,$identifier);
    }
    $date = new DateTime("$date $time", new DateTimeZone($a[0]));        
            $date->setTimezone(new DateTimeZone($timeZoneTo));
             return array(
             "newDate"=>$date->format('d.m.Y'),
             "newTime"=> $date->format('H:i:s')
             );
             
             //return  $date->format('H:i:s');


}
function floatvalue($val){
    $val = str_replace(",",".",$val);
    $val = preg_replace('/\.(?=.*\.)/', '', $val);
    return floatval($val);
}

function getDistanceBetweenPoints($lat1, $lon1, $lat2, $lon2) {
	$theta = $lon1 - $lon2;
	$miles = (sin(deg2rad($lat1)) * sin(deg2rad($lat2))) + (cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta)));
	$miles = acos($miles);
	$miles = rad2deg($miles);
	$miles = $miles * 60 * 1.1515;
	$feet = $miles * 5280;
	$yards = $feet / 3;
	$kilometers = $miles * 1.609344;
	$meters = $kilometers * 1000;
	return compact('miles','feet','yards','kilometers','meters'); 
}
function convertDegreesToWindDirection($degrees) {
	$directions = array('N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW', 'N');
	return $directions[round($degrees / 22.5)];
}
function sortByKey(&$array, $key, $descending = false) { 
	usort($array, function($a, $b) use ($key, $descending) {
		if($a[$key] == $b[$key]) {
			return 0;
		}
		if($descending) {
			return ($a[$key] < $b[$key] ? 1 : -1);
		} else {
			return ($a[$key] > $b[$key] ? 1 : -1);
		}
	});	
}
?>
