function readURL(input) {
    if (input.files && input.files[0]) {
        let reader = new FileReader();
        let img = input.nextElementSibling;
        reader.onload = function (e) {
            $(img)
                .attr('src', e.target.result);
        };

        reader.readAsDataURL(input.files[0]);
        img.style.display = 'flex';
    }
}


function showAddOption() {
    $('#add_option_form').css('display', 'flex');
}

function hideAddOption() {
    $('#add_option_form').css('display', 'none');

}

$(document).ready(()=>{
    $('#blogImageInput').change(function(){
        const file = this.files[0];
        console.log(file);
        if (file){
            let reader = new FileReader();
            reader.onload = function(event){
                console.log(event.target.result);
                $('#blogImagePreview').attr('src', event.target.result);
                $('.image-preview-box').css('display', 'flex');
                $('#blogImagePreview').addClass('img');

                if(!$('#image-preview-box').find('span').length) {
                    $('#image-preview-box').append('<span onclick="removeBlogImage();" class="material-symbols-outlined">\n' +
                        'close\n' +
                        '</span>')
                }
            }
            reader.readAsDataURL(file);
        }
    });
});

function removeBlogImage(){
    $('.image-preview-box').css('display', 'none');
    $("#blogImageInput").val('');
    $('#blogImagePreview').attr('src', '');

}

function hideFlashMsg() {
    $('#msg-flash').css('transition', '.2s');
    $('#msg-flash').css('opacity', '0');

    $('#msg-flash').delay(200).queue(function (next) {
        $(this).css('display', 'none');
        next();
    })


}
function deleteDetail(id , img){
    $.ajax({
        type: "POST",
        data: { id: id, img: img },
        url: "delete_detail",
        success: function (data) {
            if(data == "SUCCESS"){
                $("#product-"+id).remove();
            }else{
                alert(data);
            }
        },
    });
}
function deleteProduct(id){
    $.ajax({
        type: "POST",
        data: { id: id },
        url: "delete_product",
        success: function (data) {
            $("#product-"+id).remove();
        },
    });
}

function addForm(i){
    var index = i+1;
    var text = 'Izvēlies';
    let form =
        "<div id ='detail-box-"+index+"'>"+
        "<label htmlFor='detail'>Produkta detaļa</label>"+
        "<select name='detail-"+index+"' id='detailsDropdown-"+index+"' onchange='changeSingleDetails("+index+")'>"+
        "<option value='#'>"+text+"</option>"+
        "</select>"+
        "<p class = 'formBtn' id = 'addBtn-"+index+"' onClick='addForm("+index+")'>+</p>"+
        "<p class = 'formBtn' id = 'deleteBtn-"+index+"' onClick='removeForm("+index+")'>-</p>"+
        "<div id = 'detail-single-detail-"+index+"'>"+
        "</div>"+
        "</div>";
    $("#addBtn-"+i).remove();
    $("#deleteBtn-"+i).remove();
    $("#details-container").append(form);
    var id = $("#category").val()
    $.ajax({
        url: "add_product",
        type:"POST",
        data:{action:"details"},
        success: function (response) {
            response = JSON.parse(response);
            $("#detailsDropdown").html("");
            response.forEach(element=>{
                if(element.cat_id == id) {
                    $("#detailsDropdown-"+index).append("<option value='"+element.id+"'>"+element.det_name_lv+"</option>")
                }
            });

        },
    });
}
function removeForm(i){
    if(i>0) {
        $("#detail-box-" + i).remove();
        var oldBox = i - 1;
        $("#detail-box-" + oldBox).append("<p class = 'formBtn' id = 'addBtn-" + oldBox + "' onClick='addForm(" + oldBox + ")'>+</p>" + "<p class = 'formBtn' id = 'deleteBtn-" + oldBox + "' onClick='removeForm(" + oldBox + ")'>-</p>");
    }
}


let arr =[];

function drag() {
    let myFile = $("#fileinput").prop("files");
    for (var i = 0; i <= myFile.length; i++) {
        var src = URL.createObjectURL(myFile[i]);
        let name = myFile[i]['name'];
        $(".imagesList").append(
            "<div>"+"<div id = 'del-" +
            i +
            "'  onclick='del(" +
            i +
            ")'>X</div> <img style='height:150px; width: 200px' src='" +
            src +
            "' id = 'img-" +
            i +
            "' > "+"<div id = 'main-"+i+"' style = 'display:flex;' class = 'center-y'><p>Iestatīt kā titulattēlu</p> <input onclick='setMain("+i+")' id = '" + i + "' value='" + name + "' type='radio' name='radio'>"+"</div></div>"
        );
        console.log($("#fileinput").prop("files"));
    }
    $("#fileinput").disable();
}
function del(index) {
    let File = $("#fileinput").prop("files");
    $("#img-" + index).remove();
    $("#del-" + index).remove();
    $("#main-" + index).remove();
    arr.push(File[index]["name"]);
    console.log(arr);
}
function setMain(index){
    let File = $("#fileinput").prop("files");
    if(typeof index === 'string') {
        localStorage.setItem("main", index);
    }else{
        localStorage.setItem("main", File[index]['name']);
    }
    console.log(localStorage.getItem("main"));
}
function upload() {
    let singleDetails = [];
    let details = [];
    $("input:checkbox[name=detailcheck]:checked").each(function(){
        const myArray = $(this).val().split("/");
        singleDetails.push(myArray[0]);
        if(!details.includes(myArray[1])) {
            details.push(myArray[1]);
        }
    });
    if(singleDetails.length<1){
        singleDetails = 'null';
    }
    if(details.length<1){
        details = 'null';
    }
    console.log('Single details:'+singleDetails);
    console.log('Details:'+details);

    if ($('input[name=radio]:checked').length > 0) {
        console.log($("#fileinput").prop("files"));
        if (arr.length < 1) {
            var deletedImages = 'all';
        } else {
            var deletedImages = arr;
        }
        var count = document.getElementById("details-container").children.length
        console.log(deletedImages);
        $('#myForm').removeAttr('onsubmit');
        var main = localStorage.getItem("main");
        document.getElementById("myForm").action =
            "add_product/" + deletedImages + "/" + main +"/"+singleDetails+"/"+details;
    }else{
        alert("Lūdzu izvēlaties titulattēlu!");
    }

}
function changeDetails(){
    var id = $("#category").val()
    var details = document.getElementById("details-container").children.length
    $.ajax({
        url: "add_product",
        type:"POST",
        data:{action:"details"},
        success: function (response) {
            response = JSON.parse(response);
            for (let i = 0; i<=details; i++){
                $("#detailsDropdown-"+i).html("");
                $("#detailsDropdown-"+i).append("<option>Izvēlies</option>")
                response.forEach(element=> {
                    if (element.cat_id == id) {
                        $("#detailsDropdown-"+i).append("<option value='" + element.id + "'>" + element.det_name_lv + "</option>");
                    }
                });
            }

        },
    });
}
function changeSingleDetails(i){
    var id = $("#detailsDropdown-"+i).val()
    var details = document.getElementById("details-container").children.length
    $.ajax({
        url: "add_product",
        type:"POST",
        data:{action:"singleDetails"},
        success: function (response) {
            response = JSON.parse(response);
            $("#detail-single-detail-"+i).html("");
            response.forEach(element=> {
                if (element.det_id == id) {
                    $("#detail-single-detail-"+i).append(
                        "<div>"+
                        "<input type='checkbox' name = 'detailcheck' value='"+element.id+"/"+element.det_id+"'>"+
                        "<p>"+element.s_det_name+"</p>"+
                        "<img style='width: 100px; height: 100px' src = 'http://localhost/bb-Niks"+element.img_url+"'>"+
                        "</div>");
                }
            });
            console.log(response);
        },
    });
}
function updateMain(index, id){
    $.ajax({
        type: "POST",
        data: { main_id: index, product_id:id, action: "set_main"},
        url: "edit_product",
        success: function (data) {
            if(data == 'SUCCESS'){
            }else{
                alert(data);
            }
        },
    });
}
function editDel(id) {
    $.ajax({
        type: "POST",
        data: {id: id, action: 'delImg'},
        url: "edit_product",
        success: function (data) {
            if (data == 'SUCCESS') {
                $("#imgContainer-" + id).remove();
            } else {
                alert(data);
            }
        },
    });
}
function editProduct(id) {
    $.ajax({
        type: "POST",
        data: {id: id, action: 'editProduct'},
        url: "edit_product",
    });
}

function hideFlashMsg() {
    $('#msg-flash').css('transition', '.2s');
    $('#msg-flash').css('opacity', '0');

    $('#msg-flash').delay(200).queue(function (next) {
        $(this).css('display', 'none');
        next();
    })


}


