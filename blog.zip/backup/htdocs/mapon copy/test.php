<?php
 include "db.php";
// $username = "test1";
// $password = "test1";
// $hashed = password_hash($password, PASSWORD_DEFAULT);
// $confirm = "test1";
// $test = null;
// if(!empty($password) && !empty($username) && !empty($confirm)){
//     if($password == $confirm){
//         try {
//             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//             $users = $conn->prepare("SELECT * FROM users");
//             $users->execute();
//             foreach($users as $user){
//                 // if($username == $user['username'] or empty($user['username'])){
//                 //     $test = false;
//                 // }else{
//                 //     $test = true;
//                 // }   
//                 if(empty($user)){
//                     echo "tukss";
//                 }
//             }
//         } catch(PDOException $e) {
//             echo "Error: " . $e->getMessage();
//         }
//         if($test == true ){
//             try {
//                 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//                 $sql = "INSERT INTO users (username, password ) VALUES ( '$username', '$hashed')";
//                 $conn->exec($sql);
//                 //echo "New record created successfully";
//               } catch(PDOException $e) {
//                 echo $sql . "<br>" . $e->getMessage();
//               }
//         }else{
//             //echo "User already exist";
//         }
//     }else{
//         //echo"Passwords doesnt match";
//     }
// }else{
//     //echo "Please enter password and username";
// }
try {
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $users = $conn->prepare("SELECT * FROM users");
    $users->execute();
    foreach($users as $user){
        if(empty($user)){
            echo "tukss";
        }
       
    }
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}