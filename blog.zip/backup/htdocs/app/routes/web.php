<?php

use App\Http\Controllers\InsertController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('list',[
        "users" => DB::select("SELECT * FROM users"),
    ]);
});
Route::get('/user/{id}', function ($id) {
    return view('user',[
        "users" => DB::select("SELECT * FROM users WHERE id = '$id'"),
        //"name"=> $users->name,
    ]);
});
Route::get('/comments/{id}', function ($id) {
    return view('comments',[
        "users" => DB::select("SELECT * FROM users WHERE id = '$id'"),
        "comments" => DB::select("SELECT * FROM comments WHERE user_id = '$id'"),
    ]);
});
Route::get('/insert/{id}', function ($id) {
    return view('insertComment', [
        "users" => DB::select("SELECT * FROM users WHERE id = '$id'"),
    ]);
});
Route::get('/kk', function () {
    return view('koks',[
        "users" => DB::select("SELECT * FROM users"),
    ]);
});

$i=1;
Route::post('/insert/{id}',[InsertController::class, 'store']);

