<?php
include "db.php";
$data = file_get_contents("http://into.id.lv/tests/api.php?key=SS123YooU", true);
$data = json_decode($data);
$array1=[];
$array2 = [];
foreach($data as $unit){
    $unit = explode(";",$unit->name);
    foreach($unit as $single){
        $array = explode(":",$single);
        $array = array_map('trim',$array);
        if($array[0] ==! "" && $array[1] ==! ""){
            array_push($array1, $array[0]);
            array_push($array2, $array[1]);
        }
    }
    $test = array_combine($array1,$array2);
    $name = $test['name'];
    $age = $test['age'];
    $address = $test['address'];
    $desc = $test['desc'];
    $sql = "INSERT INTO tableApi (name, age, adress, descriptipon)
    VALUES ('$name', '$age', '$address','$desc')";
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
