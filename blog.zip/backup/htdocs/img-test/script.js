let arr = [];
function drag() {
  let myFile = $("#img").prop("files");
  for (var i = 0; i <= myFile.length; i++) {
    var src = URL.createObjectURL(myFile[i]);
    $("body").append(
      "<img src='" +
        src +
        "' id = 'img-" +
        i +
        "' > <div id = 'del-" +
        i +
        "'  onclick='del(" +
        i +
        ")'>x</div>"
    );
    console.log(src);
  }
}
function del(index) {
  let File = $("#img").prop("files");
  $("#img-" + index).remove();
  $("#del-" + index).remove();
  arr.push(File[index]["name"]);
  console.log(arr);
}
function upload() {
  var deletedImages = arr;
  document.getElementById("myForm").action =
    "upload.php?images=" + deletedImages;
}
