<?php
//nodefine klasi
class User{
    // properities (attributes)
    public $name;
    //methods (functions)
    public function sayHello(){
        return $this->name. ' Says Hello';
    }
}

// iestatiet lietotāja objektu no lietotāju klases
$user1 = new User();
$user1->name = 'MATIhhhhhhhhhh';
echo $user1->name;
echo'<br>';
echo $user1->sayHello();
echo'<br>';

//create new user
$user2 = new User();
$user2->name = 'la';
echo $user2->name;
echo'<br>';
echo $user2->sayHello();

?>