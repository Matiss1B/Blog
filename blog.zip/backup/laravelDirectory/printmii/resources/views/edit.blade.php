<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <title>Document</title>
</head>
<body>
@if (\Session::has('message'))
    <h1>{{ \Session::get('message') }}</h1>
@endif
@foreach($products as $product)
<form id = "editForm" method="post" enctype="multipart/form-data" >
    @csrf
    <div class="auth-container-login flex col gap2 pad2rem">
        <meta name="csrf-token" content="{{ csrf_token() }}" />
        <h2>Login</h2>
        <div class="input-group login-input-name flex col">
            <label for="uname">Title</label>
            <input type="text" value = "{{$product->title}}" name="title" id = "title">
            @if ($errors->has('title'))
                <span>{{ $errors->first('title') }}</span>
            @endif
        </div>
        <div class="input-group login-input-pass flex col">
            <label for="desc">Description</label>
            <input type="text"  value = "{{$product->description}}" name="description" id = "description">
            @if ($errors->has('description'))
                <span>{{ $errors->first('description') }}</span>
            @endif
        </div>
        <div class="input-group login-input-pass flex col">
            <label for="desc">Main img</label>
            <input type="file" name="main_img" placeholder ="Izvēlies titulattēlu" onchange="mainImgChange()" id = "main_img">
            @if ($errors->has('main_img'))
                <span>{{ $errors->first('mian_img') }}</span>
            @endif
            <div id = "main-img">
                <img style="width:200px; height: 200px;" src="{{ asset('/storage/'.$product->img)}}">
            </div>
        </div>
        <div class="input-group login-input-pass flex col">
            <label for="desc">Gallery</label>
            <input type="file" name="gallery[]" placeholder ="Izvēlies titulattēlu" id = "gallery" onchange = "upload()" multiple>
            @if ($errors->has('main_img'))
                <span>{{ $errors->first('mian_img') }}</span>
            @endif
            <div class="imagesList">
                @foreach($images as $img)
                    <div id = "imageConatiner-{{$img->id}}">
                        <div onclick="delImg({{$img->id}})">X</div>
                        <img style="width:200px; height: 200px;" src="{{ asset('/storage/'.$img->img_url)}}">
                    </div>
                @endforeach
            </div>
        </div>
        <div class="input-group login-input-name flex col">
            <label for="price">Price</label>
            <input type="number" value="{{$product->price}}" name="price" id = "price">
            @if ($errors->has('price'))
                <span>{{ $errors->first('price') }}</span>
            @endif
        </div>
        <div class="input-group login-input-name flex col">
            <label for="price">Category</label>
            <select name="category_id" id="category_id">
                @foreach($categories as $category)
                <option value="{{$category->id}}">{{$category->category}}</option>
                @endforeach
            </select>
            @if ($errors->has('category_id'))
                <span>{{ $errors->first('category_id') }}</span>
            @endif
        </div>
        <div id="details">
                @foreach($details as $detail)
                        <form method="post" action="http://localhost/laravelDirectory/printmii/public/editDetail/{{$detail->id}}">
                            @csrf
                            <label>Detala</label>
                            <input type="text" value = "{{$detail->detail}}" name="detail-{{$detail->id}}" id = "detail-{{$detail->id}}">
                            <button type = "submit">Mainit</button>
                        </form>
                        <form method="post" action="http://localhost/laravelDirectory/printmii/public/deleteDetail/{{$detail->id}}">
                            @csrf
                            <button type = "submit">Dzest</button>
                        </form>
                @endforeach
        </div>
    </div>
        <button type="submit" onclick="editProduct({{$product_id}})">Add</button>

    </div>
</form>
@endforeach
</body>
<script src="../../resources/js/script.js"></script>
</html>
