    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
        <title>Document</title>
    </head>
    <div class="homeView flex col w-100vh h-100vh alignCenter justifyCenter ">
        @if (\Session::has('message'))
            <h1>{{ \Session::get('message') }}</h1>
        @endif
            <div class="auth-container flex gap2">
                <div class="hide-box w-50 h-50">kdkkk</div>
                <form action="{{route('postlogin')}}" method="post">
                    @csrf
                    <div class="auth-container-login flex col gap2 pad2rem">
                    <h2>Login</h2>
                    <div class="input-group login-input-name flex col">
                        <label for="uname">Email</label>
                        <input type="text" placeholder="Enter Username" name="email" id = "email">
                        @if ($errors->has('email'))
                        <span>{{ $errors->first('email') }}</span>
                        @endif
                    </div>
                    <div class="input-group login-input-pass flex col">
                        <label for="psw">Password</label>
                        <input type="password" placeholder="Enter Password" name="password" id = "password">
                        @if ($errors->has('password'))
                        <span>{{ $errors->first('password') }}</span>
                        @endif
                        <div class="remember flex gap10px marT10px">
                            <input type = "checkbox" id = "remember_me" value="remember_me" name = "remember_me">
                            <p>Remember me!</p>
                        </div>
                    </div>
                    <div class="auth-container-submit flex col gap10px">
                        <button type="submit">Login</button>
                        <div class="register-btn flex gap10px">
                            Don't have an account?
                        <a href = "{{route('register')}}">Register</a>
                        </div>
                    </div>
                </div>
                </form>
            </div>
    </div>

