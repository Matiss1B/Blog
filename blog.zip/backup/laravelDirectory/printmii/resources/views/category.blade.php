@extends('layout');
@section('content')
@if (\Session::has('message'))
    <h1>{{ \Session::get('message') }}</h1>
@endif
<form action="addCategory" method="post" enctype="multipart/form-data" >
    @csrf
    <div class="auth-container-login flex col gap2 pad2rem">
        <h2>Category</h2>
        <div class="input-group login-input-name flex col">
            <label for="uname">Category</label>
            <input type="text" placeholder="Enter Category" name="category" id = "category">
            @if ($errors->has('title'))
                <span>{{ $errors->first('title') }}</span>
            @endif
        </div>
        <button type="submit">Add</button>

    </div>
</form>
<div class="imagesList"></div>
@endsection
