<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

        <title>Document</title>
    </head>
    <body>
    @if (\Session::has('message'))
            <h1>{{ \Session::get('message') }}</h1>
        @endif
            <form  id = "productForm" method="post" enctype="multipart/form-data" >
                @csrf
                <div class="auth-container-login flex col gap2 pad2rem">
                    <h2>Login</h2>
                    <div class="input-group login-input-name flex col">
                        <label for="uname">Title</label>
                        <input type="text" placeholder="Enter Username" name="title" id = "title">
                        @if ($errors->has('title'))
                        <span>{{ $errors->first('title') }}</span>
                        @endif
                    </div>
                    <div class="input-group login-input-pass flex col">
                        <label for="desc">Description</label>
                        <input type="text" placeholder="Enter Description" name="description" id = "description">
                        @if ($errors->has('description'))
                        <span>{{ $errors->first('description') }}</span>
                        @endif
                    </div>
                    <div class="input-group login-input-pass flex col">
                        <label for="desc">Main img</label>
                        <input type="file" name="main_img" placeholder ="Izvēlies titulattēlu" id = "main_img">
                        @if ($errors->has('main_img'))
                        <span>{{ $errors->first('mian_img') }}</span>
                        @endif
                    </div>
                    <div class="input-group login-input-pass flex col">
                        <label for="desc">Gallery</label>
                        <input type="file" name="gallery[]" placeholder ="Izvēlies titulattēlu" id = "gallery" onchange = "upload()" multiple>
                        @if ($errors->has('main_img'))
                        <span>{{ $errors->first('mian_img') }}</span>
                        @endif
                    </div>
                    <div class="input-group login-input-name flex col">
                        <label for="price">Price</label>
                        <input type="number" placeholder="Enter Price" name="price" id = "price">
                        @if ($errors->has('price'))
                        <span>{{ $errors->first('price') }}</span>
                        @endif
                    </div>
                    <div class="input-group login-input-name flex col">
                        <label for="price">Category</label>
                        <select name="category_id" id="category_id">
                            <option value="1">Calendar</option>
                        </select>
                        @if ($errors->has('category_id'))
                        <span>{{ $errors->first('category_id') }}</span>
                        @endif
                    </div>
                    <div class="input-group login-input-name flex col">
                        <label for="detail_title">Details</label>
                        <div id = "details">
                            <div id="detail-box-0">
                        <input type="text" placeholder="Detail title" name="detail_title-0" id = "detail_title-0">
                        @if ($errors->has('detail_title'))
                            <span>{{ $errors->first('detail_title') }}</span>
                        @endif
                        <input type="text" placeholder="Detail" name="detail-0" id = "detail-0">
                        @if ($errors->has('detail'))
                            <span>{{ $errors->first('detail') }}</span>
                        @endif
                            <p id = "detBtn-0" onclick="addDetail(0)">Add one more detail</p>
                            </div>

                        </div>
                    </div>
                        <button type="submit" onclick="addProduct()">Add</button>

                    </div>
            </form>
            <div class="imagesList"></div>
    </body>
<script src="../resources/js/script.js"></script>
</html>
