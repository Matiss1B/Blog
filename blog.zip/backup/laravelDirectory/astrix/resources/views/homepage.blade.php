@extends('layouts/app')
@section('content')
    <div class="homepage flex col alignCenter justifyCenter  h-100">
        <section class="section-1 flex col red">
            <div class="section-1-blur-box ">ccc</div>
        </section>
    </div>
@endsection

