$(document).ready(function () {
    $.ajax({
        dataType: "json",
        url: "http://localhost/example-app/public/api/posts",
        success: function (data) {
            console.log(data);
        },
    });
});
function register() {
    $(".hide-box").css("animation-name", "hide");
    $(".hide-box").css("animation-duration", "0.5s");
}
